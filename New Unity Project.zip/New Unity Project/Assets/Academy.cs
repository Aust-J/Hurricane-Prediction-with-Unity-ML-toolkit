﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
using UnityEditor;
#endif
namespace MLAgents

public class Academy : MonoBehaviour {

	// Use this for initialization
	void Start () {
		var brains = GetBrains(gameObject);
            InitializeAcademy();
            MLAgents.Communicator communicator = null;

            // Try to launch the communicator by usig the arguments passed at launch
            try
            {
                communicator = new MLAgents.RPCCommunicator(
                    new MLAgents.CommunicatorParameters
                    {
                        port = ReadArgs()
                    });
		}
		var externalBrain = brains.FirstOrDefault(b => b.brainType == BrainType.External);
		if (externalBrain != null)
		{
			communicator = new MLAgents.RPCCommunicator(
				new MLAgents.CommunicatorParameters
				{
					port = 5005
				});
		}
	}

	brainBatcher = new MLAgents.Batcher(communicator);

	// Initialize Brains and communicator (if present)
	foreach (var brain in brains)
	{
		brain.InitializeBrain(this, brainBatcher);
	}

	if (communicator != null)
	{
		isCommunicatorOn = true;

		var academyParameters =
			new MLAgents.CommunicatorObjects.UnityRLInitializationOutput();
		academyParameters.Name = gameObject.name;
		academyParameters.Version = kApiVersion;
		foreach (var brain in brains)
		{
			var bp = brain.brainParameters;
			academyParameters.BrainParameters.Add(
				MLAgents.Batcher.BrainParametersConvertor(
					bp,
					brain.gameObject.name,
					(MLAgents.CommunicatorObjects.BrainTypeProto)
					brain.brainType));
		}


		academyParameters.EnvironmentParameters =
			new MLAgents.CommunicatorObjects.EnvironmentParametersProto();
		foreach (var key in resetParameters.Keys)
		{
			academyParameters.EnvironmentParameters.FloatParameters.Add(
				key, resetParameters[key]
			);
		}

		var pythonParameters = brainBatcher.SendAcademyParameters(academyParameters);
		Random.InitState(pythonParameters.Seed);
		Application.logMessageReceived += HandleLog;
		logPath = Path.GetFullPath(".") + "/UnitySDK.log";
		logWriter = new StreamWriter(logPath, false);
		logWriter.WriteLine(System.DateTime.Now.ToString());
		logWriter.WriteLine(" ");
		logWriter.Close();
	}


		
	}
	
private void UpdateResetParameters()
{
	var newResetParameters = brainBatcher.GetEnvironmentParameters();
	if (newResetParameters != null)
	{
		foreach (var kv in newResetParameters.FloatParameters)
		{
			resetParameters[kv.Key] = kv.Value;
		}
	}
}


	private int ReadArgs()
	{
		var args = System.Environment.GetCommandLineArgs();
		var inputPort = "";
		for (var i = 0; i < args.Length; i++)
		{
			if (args[i] == "--port")
			{
				inputPort = args[i + 1];
			}
		}

		return int.Parse(inputPort);
	}

}
