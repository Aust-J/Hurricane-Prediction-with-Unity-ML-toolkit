﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hurricane : Agent {
	

	// Use this for initialization, respawn randomly based on training from input 
	//of external tensorflow/python brain
	void Start (int latWeight, int longWeight) {
		recordExperiences = true;
		resetBuffer = false;
		myAgent = GetComponent<Agent>();
		bufferResetTime = Time.time;
	}

	void Update ( ){ // double curl, int directionX, int directionZ) {
		transform.Translate(Vector3.left * Time.deltaTime);

		// Move the object upward in world space 1 unit/second.
		transform.Translate(Vector3.up * Time.deltaTime, Space.World);
	
		if(time > value || distance > dValue){ EndRespawn (); }
	}

	void EndRespawn(){
		Transform.Destroy	
		var vectorActionSize = _brainParameters.vectorActionSize;
		var runningSum = 0;
		var result = new int[vectorActionSize.Length + 1];
		for (var actionIndex = 0;
			actionIndex < vectorActionSize.Length; actionIndex++)
		{
			runningSum += vectorActionSize[actionIndex];
			result[actionIndex + 1] = runningSum;
		}
	}


}


